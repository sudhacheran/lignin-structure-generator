package com.mol.util;

public class lcLogger {

	public static void sop(String str, String classname) {
		System.out.println(classname + " : " + str);

	}
}
