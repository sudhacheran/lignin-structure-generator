#!/bin/csh
java -jar lgs-generator-1.0.jar
